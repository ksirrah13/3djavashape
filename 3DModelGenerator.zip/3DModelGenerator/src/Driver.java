/**
 * Created by kyle on 12/3/14.
 */
public class Driver {

    //simple driver program for program
    public static void main(String[] args) {
        GUI demo = new GUI();

    }

}
